package �������ϵͳ;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;


public class LoginJFrame extends JFrame {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public LoginJFrame() {

        setTitle("ѧ����¼");
        setBounds(300, 200, 300, 200);
        Container cp = getContentPane();
        cp.setLayout(null);
        JLabel jl = new JLabel("�û�����");
        jl.setBounds(10, 10, 200, 18);
        final JTextField name = new JTextField();
        name.setBounds(80, 10, 150, 18);
        JLabel jl2 = new JLabel("���룺");
        jl2.setBounds(10, 50, 200, 18);
        final JPasswordField password = new JPasswordField();
        password.setBounds(80, 50, 150, 18);
        cp.add(jl);
        cp.add(name);
        cp.add(jl2);
        cp.add(password);
        JButton jb = new JButton("ȷ��");
        jb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	Connection con = jdbc.getConnection("root","520");
                if (name.getText().trim().length() == 0
                        || new String(password.getPassword()).trim()
                                .length() == 0) {
                    JOptionPane.showMessageDialog(null, "�û������벻����Ϊ��");
                    return;
                }else {
                	String youPassword = String.valueOf(password.getPassword());
                	String youName = name.getText();

                	try {
    					boolean yz = jdbc.checkLogin(youName, youPassword);;
    					 if (yz == false) {
    		                    JOptionPane.showMessageDialog(null, "�û������������");
    		                } else{
    		                    JOptionPane.showMessageDialog(null, "��¼�ɹ�");
    		                	setVisible(false);
    		                	new StudentJFrame(youPassword);
    		                } 
    				} catch (SQLException e) {
    					// TODO �Զ����ɵ� catch ��
    					e.printStackTrace();
    				}
              } 
               jdbc.releaseConnectin(con); 
            }
        });
        jb.setBounds(80, 80, 60, 18);
        cp.add(jb);

        final JButton button = new JButton();
        button.setText("����");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                // TODO �Զ����ɷ������
                name.setText("");
                password.setText("");
            }
        });
        button.setBounds(150, 80, 60, 18);
        getContentPane().add(button);
        JButton Adminjb = new JButton("����Ա��¼");
        Adminjb .setBounds(30, 110, 100, 18);
        cp.add(Adminjb);
        Adminjb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                setVisible(false);
                new AdminLogin();
            }
        });
        
        JButton Teacherjb = new JButton("��ʦ��¼");
        Teacherjb.setBounds(140, 110, 100, 18);
        cp.add(Teacherjb);
        Teacherjb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                setVisible(false);
                new TeacherLogin();
            }
        });

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setVisible(true);
        
    }

    public static void main(String[] args) {
        new LoginJFrame();
    }

}


